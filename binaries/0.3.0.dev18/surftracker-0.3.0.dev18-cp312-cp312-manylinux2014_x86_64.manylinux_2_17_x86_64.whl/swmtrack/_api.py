"""Compatibility for ordinary Python dataclass metadata in native modules."""
from dataclasses import dataclass
from typing import get_type_hints


def public_dataclass(cls):
    # Cython stores class annotations as strings. Resolve them before generating
    # dataclass fields/__init__ so their types match the source API exactly.
    cls.__annotations__ = get_type_hints(cls)
    return dataclass(cls)
