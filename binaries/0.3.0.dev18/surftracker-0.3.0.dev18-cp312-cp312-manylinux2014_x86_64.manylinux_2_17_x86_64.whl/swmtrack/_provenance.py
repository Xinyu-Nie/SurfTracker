"""Installed implementation identity for source and compiled distributions."""
from importlib.util import find_spec
from pathlib import Path
import hashlib
import json


def module_hash(name):
    origin = find_spec('swmtrack.' + name).origin
    return hashlib.sha256(Path(origin).read_bytes()).hexdigest()


def implementation_hashes():
    root = Path(__file__).parent
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.iterdir()) if p.is_file()
            and (p.suffix in ('.py', '.so', '.pyd') or p.name == '_build_manifest.json')}


def build_info():
    path = Path(__file__).with_name('_build_manifest.json')
    return json.loads(path.read_text()) if path.is_file() else {'implementation': 'python-numba'}
