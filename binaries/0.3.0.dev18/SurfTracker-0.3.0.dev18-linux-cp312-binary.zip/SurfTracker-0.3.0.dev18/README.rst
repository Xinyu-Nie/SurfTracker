SurfTracker 0.3.0.dev18: compiled binary kit
============================================

This build targets CPython 3.12 on Linux x86_64. Native dependency auditing
permits manylinux2014 / glibc 2.17 tags; execution was tested on glibc 2.31.
Other operating systems, Python ABIs and architectures need separate builds.

Create a fresh Python 3.12 environment, then install the supplied wheel::

    python3.12 -m venv surftracker-env
    . surftracker-env/bin/activate
    python -m pip install -c requirements-validation.txt *.whl
    swmtrack doctor
    swmtrack run --help
    python scripts/synthetic_demo.py --output-dir output/synthetic
    python scripts/validate_installation.py --demo output/synthetic/demo.json

The constraints reproduce the numerical dependency versions used in validation.
The synthetic example produces 98 accepted streamlines from 256 attempts and
exports VTK/TCK/TRK files. It contains no human data and does not exercise
cortical segmentation. See docs/ for real input requirements, recommended
settings, MRtrix3 FOD conventions, orientation, ROI selection, optional ANTs
registration and QC. The command and import name remain swmtrack.

No compiler or Cython runtime is required. The scientific core loads from native
modules; readable CLI/I/O/registration/validation and API adapters accompany it.
Numba remains a dependency for thread-configuration compatibility. Core source,
generated C/Cython files, private build logs and human datasets are excluded.

Use sha256sum -c SHA256SUMS to verify the kit files. VALIDATION.rst records the
scientific/installation checks and their scope. Citation/contributor credits and
dependency notices are supplied. Project-wide licensing terms remain unspecified;
dependency notices apply to their respective components rather than licensing
SurfTracker itself. Earlier public source revisions remain in Git history.

Documentation and issue tracker: https://github.com/Xinyu-Nie/SurfTracker .
